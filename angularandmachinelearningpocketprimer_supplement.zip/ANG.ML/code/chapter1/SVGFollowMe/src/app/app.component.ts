import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<div><mouse-move></mouse-move></div>'
})
export class AppComponent { }
