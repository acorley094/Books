import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<div>Goodbye<child-comp></child-comp>World!</div>`
})
export class AppComponent {}
