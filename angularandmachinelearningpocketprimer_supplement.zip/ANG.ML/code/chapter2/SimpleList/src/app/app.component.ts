import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<div *ngFor="let item of items">
               {{item}}
             </div>`
})
export class AppComponent {
  items = [];

  constructor() {
    this.items = ['one','two','three','four'];
  }
}

