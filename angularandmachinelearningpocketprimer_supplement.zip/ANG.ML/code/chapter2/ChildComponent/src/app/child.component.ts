import {Component} from '@angular/core';

@Component({
   selector: 'child-comp',
   template: `<div>Hello World from ChildComponent!</div>`
}) 
export class ChildComponent{}

