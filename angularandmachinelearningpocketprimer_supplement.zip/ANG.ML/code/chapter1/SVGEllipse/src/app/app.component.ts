import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<my-svg></my-svg>',
  styleUrls: ['./app.component.css']
})
export class AppComponent { }
