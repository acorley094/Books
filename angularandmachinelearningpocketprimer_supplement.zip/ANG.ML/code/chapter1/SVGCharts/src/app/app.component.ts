import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<div><mycharts></mycharts></div>'
})
export class AppComponent { }
